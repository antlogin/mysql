-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: food_layout
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `avg_weight_per_person`
--

DROP TABLE IF EXISTS `avg_weight_per_person`;
/*!50001 DROP VIEW IF EXISTS `avg_weight_per_person`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `avg_weight_per_person` AS SELECT 
 1 AS `AVG_weight_per_person`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `complete_grocery_list`
--

DROP TABLE IF EXISTS `complete_grocery_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complete_grocery_list` (
  `name` varchar(127) DEFAULT NULL,
  `amount_of_grocery` float DEFAULT NULL,
  `units` varchar(127) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complete_grocery_list`
--

LOCK TABLES `complete_grocery_list` WRITE;
/*!40000 ALTER TABLE `complete_grocery_list` DISABLE KEYS */;
INSERT INTO `complete_grocery_list` VALUES ('Баранки ОЗБИ',400,'г'),('Горошек консервированный',1.6,'банка 400г'),('Гречка',640,'г'),('Изюм ',400,'г'),('Картофель',2.88,'кг'),('Молоко концентрированное',0.8,'банка 300г'),('Компотная смесь',400,'г'),('Консервы \"Мясо с овощами\"',8,'пакет 250г'),('Кукуруза консервированная',1.6,'банка 340г'),('Курага',160,'г'),('Лук',0.56,'кг'),('Майонез',160,'г'),('Морковь',0.6,'кг'),('Мука блинная',640,'г'),('Орехи',800,'г'),('Печенье ',800,'г'),('Пшено',240,'г'),('Масло подсолнечное',344,'г'),('Рис',880,'г'),('Сало',400,'г'),('Сахар',560,'г'),('Сгущенка',2.4,'пакет 270г'),('Суп-пакеты_щи',2,'пакет 70г'),('Сухое молоко',120,'г'),('Сыр',1280,'г'),('Тушенка-говядина',4,'пакет 325г'),('Тушенка-свинина',2,'пакет 325г'),('Хлеб белый',1.6,'батон 400г'),('Хлеб черный',1.6,'буханка 800г'),('Чай',280,'г'),('Чеснок',0.176,'кг');
/*!40000 ALTER TABLE `complete_grocery_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dishes`
--

DROP TABLE IF EXISTS `dishes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dishes` (
  `fk_dish_name_id` bigint DEFAULT NULL,
  `fk_grocery_id` bigint DEFAULT NULL,
  `quantity_per_person` float DEFAULT NULL,
  KEY `fk_dish_name_id` (`fk_dish_name_id`),
  KEY `fk_grocery_id` (`fk_grocery_id`),
  CONSTRAINT `dishes_ibfk_1` FOREIGN KEY (`fk_dish_name_id`) REFERENCES `dishes_names` (`id`),
  CONSTRAINT `dishes_ibfk_2` FOREIGN KEY (`fk_grocery_id`) REFERENCES `grocery` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dishes`
--

LOCK TABLES `dishes` WRITE;
/*!40000 ALTER TABLE `dishes` DISABLE KEYS */;
INSERT INTO `dishes` VALUES (1,10,1),(2,36,0.05),(2,32,40),(3,40,5),(3,26,10),(4,20,25),(5,18,50),(6,6,0.3),(6,35,0.25),(6,16,0.03),(6,13,0.025),(6,22,7),(6,41,0.007),(6,11,0.2),(7,38,0.05),(8,1,50),(9,23,30),(9,21,30),(9,4,20),(9,12,20),(9,27,0.1),(9,8,0.1),(10,9,50),(11,38,0.1),(11,25,50),(12,3,80),(12,34,0.25),(12,13,0.015),(12,22,7),(12,41,0.005),(12,2,0.2),(13,30,15),(13,4,30),(13,27,0.2),(13,22,15),(14,28,0.25),(14,6,0.06),(14,16,0.015),(14,13,0.01),(14,41,0.005),(14,22,4),(14,14,20),(15,23,80),(15,34,0.25),(15,13,0.02),(15,41,0.005),(15,22,10),(15,16,0.03),(13,17,80),(16,21,70),(16,4,20),(16,12,20),(16,27,0.1),(16,8,0.1),(17,39,20),(17,33,35),(18,42,0.25),(19,19,0.25),(20,15,90),(20,35,0.25),(20,13,0.01),(20,22,8),(20,41,0.005),(20,5,0.2),(20,7,0.05),(21,39,10);
/*!40000 ALTER TABLE `dishes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dishes_names`
--

DROP TABLE IF EXISTS `dishes_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dishes_names` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `dish_name` varchar(127) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dishes_names`
--

LOCK TABLES `dishes_names` WRITE;
/*!40000 ALTER TABLE `dishes_names` DISABLE KEYS */;
INSERT INTO `dishes_names` VALUES (1,'Мясо с овощами'),(2,'Бутерброд с сыром'),(3,'Чай с сахаром'),(4,'Печенье'),(5,'Орехи'),(6,'Картошка с тушенкой'),(7,'Хлеб черный'),(8,'Баранки'),(9,'Каша Дружба'),(10,'Компот'),(11,'Бутерброд с салом'),(12,'Гречка с тушенкой'),(13,'Оладьи'),(14,'Щи'),(15,'Рис с тушенкой'),(16,'Каша пшенная'),(17,'Хлебцы с сыром'),(18,'Шпроты'),(19,'Паштет'),(20,'Макароны с тушенкой'),(21,'Хлебцы');
/*!40000 ALTER TABLE `dishes_names` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food_layout_profile`
--

DROP TABLE IF EXISTS `food_layout_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `food_layout_profile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(127) NOT NULL,
  `author_name` varchar(127) NOT NULL,
  `author_email` varchar(127) NOT NULL,
  `event_start_date` date NOT NULL,
  `event_end_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food_layout_profile`
--

LOCK TABLES `food_layout_profile` WRITE;
/*!40000 ALTER TABLE `food_layout_profile` DISABLE KEYS */;
INSERT INTO `food_layout_profile` VALUES (1,'Водный поход на 4 дня','Антон','ak_l@mail.ru','2021-08-23','2021-08-26'),(2,'Пеший поход на 3 дня','Антон','ak_l@mail.ru','2021-09-23','2021-09-25');
/*!40000 ALTER TABLE `food_layout_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grocery`
--

DROP TABLE IF EXISTS `grocery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `grocery` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(63) NOT NULL,
  `proteins` float DEFAULT NULL,
  `fats` float DEFAULT NULL,
  `carbohydrates` float DEFAULT NULL,
  `calories` float DEFAULT NULL,
  `fk_units_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_units_id` (`fk_units_id`),
  CONSTRAINT `grocery_ibfk_1` FOREIGN KEY (`fk_units_id`) REFERENCES `units` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grocery`
--

LOCK TABLES `grocery` WRITE;
/*!40000 ALTER TABLE `grocery` DISABLE KEYS */;
INSERT INTO `grocery` VALUES (1,'Баранки ОЗБИ',8,6,68,356,2),(2,'Горошек консервированный',5.5,0.7,7.4,74,8),(3,'Гречка',13,3,68,350,2),(4,'Изюм ',3,1,66,264,2),(5,'Кабачковая икра',1,0,5,26,9),(6,'Картофель',2.4,0.4,12.4,61,1),(7,'Кетчуп',1.8,1,22,93,10),(8,'Молоко концентрированное',6.4,7.8,10.3,138,11),(9,'Компотная смесь',1,0,8,42,2),(10,'Консервы \"Мясо с овощами\"',7,6,13,126,12),(11,'Кукуруза консервированная',2.2,0,11.2,58,4),(12,'Курага',5,0.3,51,215,2),(13,'Лук',1,0,10,47,1),(14,'Майонез',2.2,67,4,627,2),(15,'Макароны',11,1,69,337,2),(16,'Морковь',1,0,7,32,1),(17,'Мука блинная',10,2,69,336,2),(18,'Орехи',15,40,20,500,2),(19,'Паштет',15,11,0,170,13),(20,'Печенье ',7.6,19.5,66,465,2),(21,'Пшено',12,3,69,350,2),(22,'Масло подсолнечное',0,0,99,900,2),(23,'Рис',7,1,79,344,2),(24,'Сайра',18,23,0,279,14),(25,'Сало',2.4,89,0,797,2),(26,'Сахар',0,0,99,398,2),(27,'Сгущенка',14,2.4,23.1,173,15),(28,'Суп-пакеты_щи',14,1,58,320,16),(29,'Сухари',10,2,77,347,2),(30,'Сухое молоко',26,25,38,476,2),(31,'Сушки',6,10,46,300,2),(32,'Сыр',24,30,1,360,2),(33,'Сыр плавленый',24,20,0,300,2),(34,'Тушенка-говядина',15,17,0,213,3),(35,'Тушенка-свинина',16,18,0,226,3),(36,'Хлеб белый',7,3,50,264,6),(37,'Хлеб Бородинский',5,1,40,200,17),(38,'Хлеб черный',7,1,41,206,7),(39,'Хлебцы ',10,3,61,350,2),(40,'Чай',0,0,0,0,2),(41,'Чеснок',6,1,30,143,1),(42,'Шпроты ',16,31,0,340,18),(43,'Яичный порошок',32,20,0,308,2);
/*!40000 ALTER TABLE `grocery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `fk_repasts_list_id` bigint NOT NULL,
  `fk_dish_name_id` bigint NOT NULL,
  KEY `fk_repasts_list_id` (`fk_repasts_list_id`),
  KEY `fk_dish_name_id` (`fk_dish_name_id`),
  CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`fk_repasts_list_id`) REFERENCES `repasts_list` (`id`),
  CONSTRAINT `menu_ibfk_2` FOREIGN KEY (`fk_dish_name_id`) REFERENCES `dishes_names` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(2,6),(2,7),(2,3),(2,8),(3,9),(3,2),(3,3),(4,10),(4,2),(4,11),(4,5),(5,12),(5,7),(5,3),(5,4),(6,13),(6,2),(6,3),(7,14),(7,3),(7,4),(8,15),(8,3),(8,4);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repasts_list`
--

DROP TABLE IF EXISTS `repasts_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repasts_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `fk_repasts_types_id` bigint DEFAULT NULL,
  `repast_name` varchar(127) DEFAULT NULL,
  `repast_date` date NOT NULL,
  `fk_layout_id` bigint NOT NULL,
  `number_of_persons` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_repasts_types_id` (`fk_repasts_types_id`),
  KEY `fk_layout_id` (`fk_layout_id`),
  CONSTRAINT `repasts_list_ibfk_1` FOREIGN KEY (`fk_repasts_types_id`) REFERENCES `repasts_types` (`id`),
  CONSTRAINT `repasts_list_ibfk_2` FOREIGN KEY (`fk_layout_id`) REFERENCES `food_layout_profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repasts_list`
--

LOCK TABLES `repasts_list` WRITE;
/*!40000 ALTER TABLE `repasts_list` DISABLE KEYS */;
INSERT INTO `repasts_list` VALUES (1,3,'Перекус на стапеле','2021-08-23',1,8),(2,4,'Первый ужин','2021-08-23',1,8),(3,1,'Первый завтрак','2021-08-24',1,8),(4,3,'Перекус','2021-08-24',1,8),(5,4,'Второй ужин','2021-08-24',1,8),(6,1,'Завтрак-оладьи','2021-08-25',1,8),(7,2,'Обед-щи','2021-08-25',1,8),(8,4,'Третий ужин','2021-08-25',1,8);
/*!40000 ALTER TABLE `repasts_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp866 */ ;
/*!50003 SET character_set_results = cp866 */ ;
/*!50003 SET collation_connection  = cp866_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `members_control` BEFORE INSERT ON `repasts_list` FOR EACH ROW BEGIN
  IF (NEW.number_of_persons < 1) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'INSERT canceled: number_of_persons < 1';
  END IF;
 END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `repasts_types`
--

DROP TABLE IF EXISTS `repasts_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repasts_types` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(63) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repasts_types`
--

LOCK TABLES `repasts_types` WRITE;
/*!40000 ALTER TABLE `repasts_types` DISABLE KEYS */;
INSERT INTO `repasts_types` VALUES (1,'Завтрак'),(2,'Обед'),(3,'Перекус'),(4,'Ужин');
/*!40000 ALTER TABLE `repasts_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `total_weight`
--

DROP TABLE IF EXISTS `total_weight`;
/*!50001 DROP VIEW IF EXISTS `total_weight`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `total_weight` AS SELECT 
 1 AS `total_weight`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `units`
--

DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `units` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(63) NOT NULL,
  `weighting_factor` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `units`
--

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,'кг',1000),(2,'г',1),(3,'пакет 325г',325),(4,'банка 340г',340),(5,'пачка 125г',125),(6,'батон 400г',400),(7,'буханка 800г',800),(8,'банка 400г',400),(9,'банка 545г',545),(10,'бутылка 570г',570),(11,'банка 300г',300),(12,'пакет 250г',250),(13,'банка 100г',100),(14,'банка 250г',250),(15,'пакет 270г',270),(16,'пакет 70г',70),(17,'буханка 400г',400),(18,'банка 175г',175);
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `avg_weight_per_person`
--

/*!50001 DROP VIEW IF EXISTS `avg_weight_per_person`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp866 */;
/*!50001 SET character_set_results     = cp866 */;
/*!50001 SET collation_connection      = cp866_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `avg_weight_per_person` AS select (((select `total_weight`.`total_weight` from `total_weight`) / (select avg(`repasts_list`.`number_of_persons`) from `repasts_list`)) / (select ((to_days(`food_layout_profile`.`event_end_date`) - to_days(`food_layout_profile`.`event_start_date`)) + 1) from `food_layout_profile` where (`food_layout_profile`.`id` = 1))) AS `AVG_weight_per_person` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `total_weight`
--

/*!50001 DROP VIEW IF EXISTS `total_weight`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp866 */;
/*!50001 SET character_set_results     = cp866 */;
/*!50001 SET collation_connection      = cp866_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `total_weight` AS select sum((`compl_groc_list`.`AMOUNT` * `u`.`weighting_factor`)) AS `total_weight` from (`units` `u` join (select `g`.`fk_units_id` AS `un`,`g`.`name` AS `NAME`,`tmp`.`Summm` AS `AMOUNT` from (`grocery` `g` join (select `d`.`fk_grocery_id` AS `gro_id`,round(sum(`d`.`quantity_per_person`),4) AS `Summm` from ((`menu` `m` join `repasts_list` `r_l`) join `dishes` `d` on(((`m`.`fk_dish_name_id` = `d`.`fk_dish_name_id`) and (`r_l`.`fk_layout_id` = 1)))) group by `d`.`fk_grocery_id` order by `d`.`fk_grocery_id`) `tmp` on((`g`.`id` = `tmp`.`gro_id`)))) `compl_groc_list` on((`compl_groc_list`.`un` = `u`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-08-16 19:12:09
